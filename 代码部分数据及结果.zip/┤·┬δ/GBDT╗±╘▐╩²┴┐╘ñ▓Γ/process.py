
import pandas as pd
import os

count = 0
def LAST():
    T_path='./new_data'#此处放入文件的路径
    file='/answer.csv'
    or_file = pd.read_csv(T_path + file)
    df = pd.DataFrame(or_file)
    Label=[]
    PT=[]
    without_biaoqian=[]
    without_name=[]
    ALL=[]
    P=[]
    T=[]
    T_B=[]
    k=0
    for i in range(len(df)):
        k=k+1
        document = df[i:i + 1]
        #print(document)
        Label.append(document['Label'][i])
        PT.append(document['PT'][i])
        ALL.append(document['ALL'][i])
        P.append(document['P'][i])
        T.append(document['T'][i])
        T_B.append(document['T_B'][i])
        without_biaoqian.append(document['without_biaoqian'][i])
        without_name.append(document['without_name'][i])


    TT_B=0
    T_ALL=0
    T_PT=0
    T_T=0
    T_P=0
    T_without_biaoqian = 0
    T_without_name = 0
    for j in range(len(Label)):
        print('---')
        print(j)
        print(Label[j])
        print(T_B[j])
        print(int(float(PT[j]) + 0.5))
        if int(Label[j])==int(float(T_B[j])+0.5):
            TT_B=TT_B+1
        if int(Label[j])==int(float(PT[j])+0.5):
            T_PT=T_PT+1
        if int(Label[j])==int(float(P[j])+0.5):
            T_P=T_P+1
        if int(Label[j])==int(float(T[j])+0.5):
            T_T=T_T+1
        if int(Label[j])==int(float(without_biaoqian[j])+0.5):
            T_without_biaoqian=T_without_biaoqian+1
        if int(Label[j])==int(float(ALL[j])+0.5):
            T_ALL=T_ALL+1
        if int(Label[j]) == int(float(without_name[j]) + 0.5):
            T_without_name = T_without_name + 1
    total=len(df)
    print('T_B')
    print(float(TT_B) / total)
    print('ALL')
    print(float(T_ALL)/total)
    print('T_without_name')
    print(float(T_without_name) / total)
    print('T_without_biaoqian')
    print(float(T_without_biaoqian) / total)
    print('T_PT')
    print(float(T_PT)/total)
    print('T_P')
    print(float(T_P) /total)
    print('T_T')
    print(float(T_T) / total)

def moveFiles(path, disdir):
    T_path=''#此处放入文件的路径
    file='/ID.csv'
    or_file = pd.read_csv(T_path + file)
    df = pd.DataFrame(or_file)
    new_Id=[]
    The_Ixd=[]
    last=[]
    k=0
    print(len(df))
    for i in range(len(df)):
        k=k+1
        print(k)
        document = df[i:i + 1]
        if k==489:
            The_Ixd.append('0aab1c95868419ef152b22cbcaa61ce7')
            continue
        if k==456:
            The_Ixd.append('631350a77dc040bdd4a14858242f1138')
            continue
        if k==492:
            The_Ixd.append('b8bffd546b799f0ca963c111cf91ec97')
            continue
        if k==494:
            The_Ixd.append('d341365dc96987991c8f25d79e8313c4')
            continue
        #print(document)
        text = document['ID'][i]
        #print(text)
        data=text.split('/').pop()
        print(data)
        dataw = data.split('~')
        #print(dataw[0])
        po=dataw[0].split('_')
        print(po)
        #print(xjj[4])

        #print(dfo[0])
        The_Ixd.append(po)


    dirlist = os.listdir(path)

    print(The_Ixd)
    The_ID = pd.DataFrame(The_Ixd)
    The_ID.to_csv(T_path + '/Txname.csv')


if __name__ == '__main__':
    # rootimage = 'C:/Users/86132/Desktop/抖音/douyin'  # 原始图片文件父目录
    # disdir = 'C:/Users/86132/Desktop/待测试图片'  # 移动到目标文件夹
    #check_same()
    # moveFiles(rootimage, disdir)
    LAST()
