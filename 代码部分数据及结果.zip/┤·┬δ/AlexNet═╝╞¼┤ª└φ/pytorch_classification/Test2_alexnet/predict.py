import os
import json
import numpy as np
import torch
from PIL import Image
from torchvision import transforms
import matplotlib.pyplot as plt
from os import listdir
from model import AlexNet
import os
import pandas
import csv
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"




def main():
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    data_transform = transforms.Compose(
        [transforms.Resize((224, 224)),
         transforms.ToTensor(),
         transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])



    # read class_indict
    json_path = './class_indices.json'
    assert os.path.exists(json_path), "file: '{}' dose not exist.".format(json_path)

    json_file = open(json_path, "r")
    class_indict = json.load(json_file)

    # create model
    model = AlexNet(num_classes=4).to(device)

    # load model weights
    weights_path = "./AlexNet.pth"
    assert os.path.exists(weights_path), "file: '{}' dose not exist.".format(weights_path)
    model.load_state_dict(torch.load(weights_path))

    # load image
    data_paths = []
    data_paths_lir = r''#插入待预测图片路径
    for path in listdir(data_paths_lir):
        data_paths.append(os.path.join(data_paths_lir, path))
    #保存数据
    last_data = {}

    n = 4
    Darry = []
    x = 0
    for img_paths in data_paths:
        img_path = img_paths

        assert os.path.exists(img_path), "file: '{}' dose not exist.".format(img_path)
       # print(img_path)
        img = Image.open(img_path)

        #plt.imshow(img)
        # [N, C, H, W]
        img = data_transform(img)
        # expand batch dimension
        img = torch.unsqueeze(img, dim=0)

        model.eval()
        with torch.no_grad():
            # predict class
            output = torch.squeeze(model(img.to(device))).cpu()
            predict = torch.softmax(output, dim=0)
            predict_cla = torch.argmax(predict).numpy()

        print_res = "class: {}   prob: {:.3}".format(class_indict[str(predict_cla)],
                                                     predict[predict_cla].numpy())
        plt.title(print_res)

        k=0
        s=img_path.split("\\")
        #print(s)
        Darry.clear()
        t=s[6]
        g=t.split(".")
        Darry.append(g[0])
        for i in range(len(predict)):
            k = k + 1
            Darry.append("{:.3}".format(predict[i].numpy()))

            #print(s[6]+"class: {:10}   prob: {:.3}".format(class_indict[str(i)],
             #                                         predict[i].numpy()))
        # The_ID = pd.DataFrame(last)
        # The_ID.to_csv(T_path + '/Tname.csv')
        #plt.show()
        #print(Darry)
        with open("./图片分析结果.csv", "a", newline="") as cf:
            w = csv.writer(cf)
            w.writerow(Darry)
            cf.close()

        #print(Darry)
    '''
    j = 0
    while j < n:
        last_data[j] = Darry[j]
        # print(data[j])
        j = j + 1

    # 目标文件

    df = pandas.DataFrame(last_data)
    df.to_csv('图片情感分析结果.csv')
    '''
if __name__ == '__main__':
    main()
