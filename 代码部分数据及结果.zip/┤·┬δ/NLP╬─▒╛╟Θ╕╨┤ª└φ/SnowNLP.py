from snownlp import SnowNLP
import numpy as np
import pandas
#with open("test.txt", "w") as f:
from string import punctuation

'''文件数据量太大，with open打不开,使用pandas'''
#原始文件
or_file = pandas.read_csv('dy文案.csv')
df = pandas.DataFrame(or_file)
#目标数据
data = {}
m=5400
n=15
Darry = np.zeros((n,m), dtype=np.float64)
x=0
yu={}
label_1=[]

for i in range(len(df)):#len(df)
 label_1.clear()
 document = df[i:i+1]
 # Name=document['Name'][i]
 # label_1.append(Name)
 text=document['文案'][i]
 label=text.split('#')
 tf=label[0]

 s=SnowNLP(text)
 k = 0;
 x=x+1
 for sentence in s.sentences:
  if k>5:
   break
  s1 = SnowNLP(s.sentences[k])
  #print(s1.sentiments)
  Darry[k][x]=(s1.sentiments)
  k = k + 1
#print(x)

j=0
while j<n:
 data[j]=Darry[j]
# print(data[j])
 j=j+1

#目标文件
print(yu)

df = pandas.DataFrame(data)
df.to_csv('文案情感分析结果.csv')
