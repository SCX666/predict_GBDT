import pandas as pd
from sklearn.model_selection import GridSearchCV
import os
from shutil import copy, rmtree
import lightgbm as lgb
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import log_loss
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')

def preProcess():
    path = './data/'
    # text_path='文案情感分析结果.csv'
    # image_path= '图片分析结果.csv'

    '''文件数据量太大，with open打不开,使用pandas'''
    data='dfa'
    #正式处理
    pd.set_option('mode.chained_assignment', None)
    path = './new_data/'

    df_train = pd.read_csv(path + 'train_f.csv')
    df_test = pd.read_csv(path + 'test_f.csv')
    test_id = df_test['ID']
    # 删除ID这一列
    df_train.drop(['ID'], axis=1, inplace=True)
    df_test.drop(['ID'], axis=1, inplace=True)

    # 把test文件中Label这一列全变为-5，-5代表未处理的
    df_test['Label'] = -1
    # 按列合并（列数不变）
    data = pd.concat([df_train, df_test])
    # 空白值全部设为-5
    data = data.fillna(-1)
    data.to_csv('../data/new_data.csv', index=False)
    return data, test_id

def gbdt_lr_predict(data,category_feature,continuous_feature):
    # 类别特征one-hot编码
    '''test_ids---60000000~?'''
    '''category_feature------C5~C26'''
    for col in category_feature:
        '''使用one_hot 编码方式，生成前缀为C5~C26的col的二进制向量'''
        onehot_feats = pd.get_dummies(data[col], prefix = col)
        '''删除这一列'''
        data.drop([col], axis = 1, inplace = True)
        '''新生成的一列矩阵加在原矩阵后面'''
        data = pd.concat([data, onehot_feats], axis = 1)
        '''train和test合并one_hot编码后拆开'''
    #print(data)
    #print(category_feature)
    # print(onehot_feats)
    train = data[data['Label'] != -1]
    target = train.pop('Label')
    test = data[data['Label'] == -1]
    test.drop(['Label'], axis = 1, inplace = True)
    #种子不同，产生不同的随机数；种子相同，即使实例不同也产生相同的随机数。通过种子取得固定随机值了。
    x_train, x_val, y_train, y_val = train_test_split(train, target, test_size=0.2, random_state=2020)
    #指定叶子的个数，默认值为31，此参数的数值应该小于 2^{max_depth}2

    n_estimators = 370 #370
    num_leaves = 164
    max_depth = 8
    learning_rate=0.01
    # 开始训练gbdt，使用500课树，每课树64个叶节点
    model = lgb.LGBMRegressor(
                              boosting_type='gbdt',
                              objective='binary',

                              max_depth=max_depth,
                              num_leaves=num_leaves,

                              subsample=0.8,
                              colsample_bytree=0.8,

                              learning_rate=learning_rate,
                              n_estimators=n_estimators,

                              random_state=2022)
    model.fit(x_train, y_train,
              eval_set=[(x_train, y_train), (x_val, y_val)],
              eval_names=['train', 'val'],
              eval_metric='binary_logloss',
              verbose=0)
    # 得到每一条训练数据落在了每棵树的哪个叶子结点上
    # pred_leaf = True 表示返回每棵树的叶节点序号
    gbdt_feats_train = model.predict(train, pred_leaf=True)
 #----------------------------调参
    # params = {
    #     'boosting_type': 'gbdt',
    #     'objective': 'binary',
    #
    #     'learning_rate': 0.01,
    #     'num_leaves': 50,
    #     'max_depth': 6,
    #
    #     'subsample': 0.8,
    #     'colsample_bytree': 0.8,
    # }
    #
    # data_train = lgb.Dataset(x_train, y_train, silent=True)
    # cv_results = lgb.cv(
    #     params, data_train, num_boost_round=1000, nfold=5, stratified=False, shuffle=True, metrics='rmse',
    #     early_stopping_rounds=50, verbose_eval=50, show_stdv=True, seed=0)
    #
    # print('best n_estimators:', len(cv_results['rmse-mean']))
    # print('best cv score:', cv_results['rmse-mean'][-1])

    # params_test1 = {
    #     'max_depth': range(3, 9, 1),
    #     'num_leaves': range(20, 170, 5)
    # }
    # gsearch1 = GridSearchCV(estimator=model, param_grid=params_test1, scoring='neg_mean_squared_error', cv=5,
    #                         verbose=1, n_jobs=4)
    #
    # gsearch1.fit(x_train, y_train)
    # print(gsearch1.best_params_)
    # print(gsearch1.best_score_)
    #return 0
    #-----------------调参结束


    # 打印结果的 shape：
   # print(gbdt_feats_train.shape)
    # 打印前5个数据：
    #print(gbdt_feats_train)

    # 同样要获取测试集的叶节点索引
    gbdt_feats_test = model.predict(test, pred_leaf=True)

    # 将 32 课树的叶节点序号构造成 DataFrame，方便后续进行 one-hot
    gbdt_feats_name = ['gbdt_leaf_' + str(i) for i in range(n_estimators)]
    #print(gbdt_feats_name)
    df_train_gbdt_feats = pd.DataFrame(gbdt_feats_train, columns=gbdt_feats_name)
   # print(df_train_gbdt_feats)
    df_test_gbdt_feats = pd.DataFrame(gbdt_feats_test, columns=gbdt_feats_name)
    train_len = df_train_gbdt_feats.shape[0]
    #print(train_len)
    data = pd.concat([df_train_gbdt_feats, df_test_gbdt_feats])
   # print(data)

    # 对每棵树的叶节点序号进行 one-hot
    for col in gbdt_feats_name:
        onehot_feats = pd.get_dummies(data[col], prefix=col)
        data.drop([col], axis=1, inplace=True)
        data = pd.concat([data, onehot_feats], axis=1)

    train = data[: train_len]
    test = data[train_len:]
    # 划分 LR 训练集、验证集
    x_train, x_val, y_train, y_val = train_test_split(train, target, test_size=0.2, random_state=2022)

    # 开始训练lr
    #训练损失分越低越好
    lr = LogisticRegression()
    lr.fit(x_train, y_train)
    print()
    tr_logloss = log_loss(y_train, lr.predict_proba(x_train)[:, 1])
    print('tr-logloss: ', tr_logloss)
    val_logloss = log_loss(y_val, lr.predict_proba(x_val)[:, 1])
    print('val-logloss: ', val_logloss)


    #print(x_val)

    # 对验证集进行测试
    #返回属于某个标签的概率
    val_predict = lr.predict_proba(x_val)[:, 1]
    from sklearn.metrics import roc_curve
    fpr, tpr, thersholds = roc_curve(y_val, val_predict)
    from sklearn.metrics import auc
    roc_auc = auc(fpr, tpr)
    print('auc is {}'.format(roc_auc))
    # 对测试集预测
    plt.plot(fpr, tpr, 'k--', label='ROC (area = {0:.2f})'.format(roc_auc), lw=2)
    plt.xlim([-0.01, 1.01])
    plt.ylim([-0.01, 1.01])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC Curve')
    plt.legend(loc="lower right")
    plt.savefig('roc.jpg')
    y_pred = lr.predict_proba(test)[:, 1]
    # print(y_pred)
    print(len(y_pred))

    with open('./new_data/submission.csv', 'w') as f:
        for idx in range(len(y_pred)):
            if y_pred[idx] >= 0.5:
                f.write('{},{}\n'.format(int(test_ids[idx]), y_pred[idx]))
            else :
                f.write('{},{}\n'.format(int(test_ids[idx]), y_pred[idx]))


#{'num_leaves': 5, 'max_depth': 7, 'max_bin': 545, 'min_data_in_leaf': 5, 'feature_fraction': 0.8, 'bagging_fraction': 0.9, 'bagging_freq': 40, 'lambda_l5': 0.0, 'lambda_l2': 0.0, 'min_split_gain': 0.0}

if __name__ == '__main__':
    #ID,1,2,3,Label,NULL,TEXT,PERSON,PT,Name,biaoqian

    data,test_ids = preProcess()
   # print(test_ids)
    #,'NULL','TEXT','PERSON','PT'
    continuous_feature = ['1','2','3']
    category_feature = ['biaoqian']
    gbdt_lr_predict(data,category_feature, continuous_feature)