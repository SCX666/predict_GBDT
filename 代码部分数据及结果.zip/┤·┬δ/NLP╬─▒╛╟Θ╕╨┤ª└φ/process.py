from snownlp import SnowNLP
import numpy as np
import pandas
#with open("test.txt", "w") as f:
from string import punctuation
#-----文件合并
def cont1():
 er_file = pandas.read_csv('处理英文label.csv')
 path = ''
 org_path = 'test.csv'
 org_peth = '处理英文label.csv'
 or_file = pandas.read_csv(path + org_path)
 df = pandas.DataFrame(or_file)
 #er_file = pandas.read_csv(path + org_peth)
 ef = pandas.DataFrame(er_file)
 data = pandas.merge(df, ef, how='left', on='0')
 data.to_csv('heing2.csv')




def fenlei():
 '''文件数据量太大，with open打不开,使用pandas'''
 #原始文件
 or_file = pandas.read_csv('test.csv')
 df = pandas.DataFrame(or_file)
 #目标数据
 data = []
 dd=[]

 for i in range(len(df)):

  x=0
  document = df[i:i+1]
  #text=document['Name'][i]
  iu=document['Name'][i]
  #print(text)
  #print(iu)
  # for j in data:
  #  if j==text:
  #   x=1
  # if x!=1:
  #  data.append(text)
  x=0
  for j in dd:
   if j == iu:
    x = 1
  if x != 1:
   dd.append(iu)
 dfx = pandas.DataFrame(dd,columns=['Name'])
 dfx.to_csv('处理英文label.csv')
 er_file = pandas.read_csv('处理英文label.csv')
 ef = pandas.DataFrame(er_file)
 print(df)
 print(ef)
 data = pandas.merge(df, ef, how='left', on='Name')
 print(data)

 data.to_csv('hebing2.csv')

 # df = pandas.DataFrame(data)
 # df.to_csv('处理英文name.csv')
if __name__ == '__main__':
 fenlei()
 #cont1()