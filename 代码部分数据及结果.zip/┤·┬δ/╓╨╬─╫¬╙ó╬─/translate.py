import requests
import json
import time
import random
import string
import hashlib

class FanYi:
    def __init__(self, keyword):
        self.keyword = keyword
        self.url = 'http://fanyi.youdao.com/translate_o?smartresult=dict&smartresult=rule'
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                          '(KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36',
            'referer': 'http://fanyi.youdao.com/',
            'cookie': 'OUTFOX_SEARCH_USER_ID=103495734@10.169.0.84'
        }

    def form_data(self):
        # 时间戳
        lts = int(time.time() * 1000)
        # 时间戳+1位随机数
        salt = str(lts) + ''.join(random.sample(string.digits, 1))
        # 组合字符串
        sign_string = 'fanyideskweb{word}{salt}]BjuETDhU)zqSxf-=B#7m'.format(word=self.keyword, salt=salt)
        # 加密
        hash = hashlib.md5()
        hash.update(sign_string.encode())
        sign = hash.hexdigest()
        data = {
            'i': self.keyword,
            'from': 'AUTO',
            'to': 'AUTO',
            'smartresult': 'dict',
            'client': 'fanyideskweb',
            'salt': salt,
            'sign': sign,
            'lts': lts,
            'bv': '02edb5d6c6ac4286cd4393133e5aab14',
            'doctype': 'json',
            'version': '2.1',
            'keyfrom': 'fanyi.web',
            'action': 'FY_BY_REALTlME'
        }
        return data

    def run(self):
        form_data = self.form_data()
        response = requests.post(self.url, headers=self.headers, data=form_data).json()
        result = response['translateResult'][0][0]['tgt']
        return result

if __name__=="__main__":
    file1 = open('标签.txt')
    text = file1.read()
    textlist = text.split('\n')
    length = len(textlist)
    file2 = open('标签英文.txt',mode='w')
    for i in range(0,length):
        input = textlist[i]
        if input == '':
            file2.write('\n')
            print('\n')
        else:
            fy = FanYi(input)
            result = fy.run()
            file2.write(result)