import requests
import pandas as pd
import os

def download_img(img_url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36'
    }
    r = requests.get(img_url, headers=headers, stream=True)
    # print(r.status_code) # 返回状态码
    if r.status_code == 200:
        # 截取图片文件名
        img_name = img_url.split('/').pop()
        #print(img_name)
        New_image=img_name.split('~')
        img_name=New_image[0]+'.jpeg'
        #print(img_name)
        with open(img_name, 'wb') as f:
            f.write(r.content)
        return True
def save_name(img_url):
    img_name = img_url.split('/').pop()
    New_image = img_name.split('~')
    img_name = New_image[0].split(':')
    name=img_name[0]
if __name__ == '__main__':
    # 下载要的图片
    T_path = 'C:/Users/86132/Desktop/最后结果'
    file = '/name.csv'
    or_file = pd.read_csv(T_path + file)
    df = pd.DataFrame(or_file)
    WEB_LIST=[]
    name=[]
    k=1
    for i in range(len(df)):
        k=k+1
        document = df[i:i + 1]
        text = document['WEB'][i]
        img_url = text

        img_name = img_url.split('/').pop()
        New_image = img_name.split('~')
        img_name = New_image[0].split(':')
        name.append(img_name[0])
    gg=pd.DataFrame(name)
    gg.to_csv('fd.csv')
        #print(img_url)
    #     ret = download_img(img_url)
    #     if not ret:
    #         print("下载失败")
    #         print(k)
    #     #print("下载成功")
    # print("结束！")
