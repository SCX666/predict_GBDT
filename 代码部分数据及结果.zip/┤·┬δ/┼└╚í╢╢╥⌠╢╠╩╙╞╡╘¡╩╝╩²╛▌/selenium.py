from selenium import webdriver
from openpyxl import Workbook
import time
url='https://www.douyin.com/search/%E7%9A%AE%E8%82%A4%E7%A7%91%E5%AF%8C%E7%A7%8B%E6%B6%9B%E5%8C%BB%E7%94%9F?publish_time=0&sort_type=0&source=switch_tab&type=video&ug_source=lenovo_edge'
latest=[]
latest_dianzan=[]
latest_author=[]
driver= webdriver.Chrome()
wb=Workbook()
sh=wb.active
driver.get(url)
time.sleep(120)
driver.implicitly_wait(20)
i,j,num=1,0,0

list_zan=driver.find_elements_by_css_selector('.fQhemzAO .VjkQxGgO')
for item in list_zan:

    latest_dianzan.append(item.text)
    num=num+1
list_author=driver.find_elements_by_css_selector('.aKgCOHgk p .Nu66P_ba span')
for item in list_author:
    author=item.get_attribute("textContent")
    if (i%8==0 or i%8==4) and len(author)<13:
        latest_author.append(author)
        #print(author,len(author),i%8==0 or i%8==4 and len(author)<11)
        
        
    
    i=i+1
list=driver.find_elements_by_css_selector('.yTHYD_5X img')
for img in list:
    time.sleep(0.4)
    title=img.get_attribute('alt')

    length=len(title)
    src=img.get_attribute('src')
    if j<num and (title[length-2:length]!='头像')and length>3:
        latest.append([title,latest_author[j],src,latest_dianzan[j]])
        print(title, latest_author[j],src,latest_dianzan[j])
        j=j+1

        
#print('ove!!!!')
for row in latest:
    sh.append(row)
    wb.save('./create_file/dy_7.xlsx')
